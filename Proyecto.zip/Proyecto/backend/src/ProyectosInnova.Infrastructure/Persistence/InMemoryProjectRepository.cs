using System.Text.Json;
using ProyectosInnova.Application.Abstractions;
using ProyectosInnova.Domain.Projects;

namespace ProyectosInnova.Infrastructure.Persistence;

public sealed class InMemoryProjectRepository : IProjectRepository
{
    private static readonly Lazy<IReadOnlyList<Project>> Projects = new(LoadProjects);

    public Task<IReadOnlyList<Project>> GetAllAsync(CancellationToken cancellationToken)
        => Task.FromResult(Projects.Value);

    public Task<Project?> GetByIdAsync(int id, CancellationToken cancellationToken)
        => Task.FromResult(Projects.Value.FirstOrDefault(project => project.Id == id));

    private static IReadOnlyList<Project> LoadProjects()
    {
        var jsonPath = FindProjectsJson();
        var json = File.ReadAllText(jsonPath);
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
        };

        var catalog = JsonSerializer.Deserialize<ProjectCatalog>(json, options)
            ?? throw new InvalidOperationException($"No se pudo leer el archivo de datos: {jsonPath}");

        return catalog.Projects
            .Select(project => new Project(
                project.Id,
                project.Title,
                project.Faculty,
                project.Responsible ?? string.Empty,
                project.Summary,
                project.Call,
                project.AcademicYear,
                project.Line,
                project.Center,
                project.DocumentFile ?? string.Empty))
            .ToArray();
    }

    private static string FindProjectsJson()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);

        while (current is not null)
        {
            var candidate = Path.Combine(current.FullName, "data", "projects.json");
            if (File.Exists(candidate))
            {
                return candidate;
            }

            current = current.Parent;
        }

        throw new FileNotFoundException("No se encontró data/projects.json en ninguna carpeta superior del ejecutable.");
    }

    private sealed record ProjectCatalog(List<ProjectSeed> Projects);

    private sealed record ProjectSeed(
        int Id,
        string Title,
        string Faculty,
        string? Responsible,
        string Summary,
        string Call,
        string AcademicYear,
        string Line,
        string Center,
        string? DocumentFile);
}
