using Microsoft.AspNetCore.Mvc;
using ProyectosInnova.Application.Projects;
using ProyectosInnova.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddInfrastructure();
builder.Services.AddCors(options =>
{
    options.AddPolicy("frontend", policy =>
        policy.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod());
});

var app = builder.Build();

app.UseCors("frontend");

app.MapGet("/", () =>
{
    const string html = """
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Proyectos de Innovacion Docente</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #0b1020;
      --panel: rgba(15, 23, 42, 0.78);
      --panel-strong: #111827;
      --text: #e5eefc;
      --muted: #9fb1cc;
      --accent: #5eead4;
      --accent-2: #60a5fa;
      --border: rgba(148, 163, 184, 0.18);
      --shadow: 0 24px 80px rgba(2, 6, 23, 0.48);
    }

    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(94, 234, 212, 0.18), transparent 28%),
        radial-gradient(circle at top right, rgba(96, 165, 250, 0.16), transparent 24%),
        linear-gradient(180deg, #0b1020 0%, #111827 100%);
      min-height: 100vh;
    }

    .wrap {
      max-width: 1180px;
      margin: 0 auto;
      padding: 40px 20px 56px;
    }

    .hero {
      display: grid;
      gap: 20px;
      grid-template-columns: 1.4fr 0.9fr;
      align-items: start;
      margin-bottom: 28px;
    }

    .panel {
      background: var(--panel);
      border: 1px solid var(--border);
      backdrop-filter: blur(14px);
      border-radius: 24px;
      box-shadow: var(--shadow);
    }

    .hero-main {
      padding: 28px;
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--accent);
      margin-bottom: 18px;
    }

    .eyebrow::before {
      content: "";
      width: 10px;
      height: 10px;
      border-radius: 999px;
      background: var(--accent);
      box-shadow: 0 0 0 6px rgba(94, 234, 212, 0.14);
    }

    h1 {
      margin: 0 0 14px;
      font-size: clamp(2.5rem, 6vw, 4.8rem);
      line-height: 0.95;
      letter-spacing: -0.05em;
    }

    .lead {
      margin: 0;
      max-width: 65ch;
      font-size: 1.02rem;
      line-height: 1.7;
      color: var(--muted);
    }

    .hero-side {
      padding: 22px;
      display: grid;
      gap: 14px;
    }

    .stat {
      padding: 18px;
      border-radius: 18px;
      background: rgba(15, 23, 42, 0.62);
      border: 1px solid var(--border);
    }

    .stat-label {
      display: block;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--muted);
      margin-bottom: 8px;
    }

    .stat-value {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--text);
    }

    .section {
      margin-top: 26px;
    }

    .section-head {
      display: flex;
      align-items: end;
      justify-content: space-between;
      gap: 16px;
      margin-bottom: 16px;
      padding: 0 4px;
    }

    .section-head h2 {
      margin: 0;
      font-size: 1.4rem;
      letter-spacing: -0.03em;
    }

    .section-head p {
      margin: 0;
      color: var(--muted);
      font-size: 0.95rem;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 16px;
    }

    .card {
      padding: 20px;
      border-radius: 20px;
      background: rgba(15, 23, 42, 0.72);
      border: 1px solid var(--border);
      min-height: 180px;
    }

    .card h3 {
      margin: 0 0 8px;
      font-size: 1.1rem;
    }

    .card p {
      margin: 0 0 16px;
      color: var(--muted);
      line-height: 1.6;
    }

    .tags {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .tag {
      font-size: 12px;
      color: #dbeafe;
      padding: 6px 10px;
      border-radius: 999px;
      background: rgba(96, 165, 250, 0.14);
      border: 1px solid rgba(96, 165, 250, 0.25);
    }

    .status {
      padding: 18px;
      border-radius: 18px;
      background: rgba(5, 150, 105, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.28);
      color: #d1fae5;
      line-height: 1.6;
    }

    .status.error {
      background: rgba(220, 38, 38, 0.12);
      border-color: rgba(248, 113, 113, 0.28);
      color: #fee2e2;
    }

    .skeleton {
      position: relative;
      overflow: hidden;
    }

    .skeleton::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.6s infinite;
    }

    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }

    @media (max-width: 860px) {
      .hero { grid-template-columns: 1fr; }
      .section-head { align-items: start; flex-direction: column; }
    }
  </style>
</head>
<body>
  <main class="wrap">
    <section class="hero">
      <div class="panel hero-main">
        <div class="eyebrow">Proyectos de Innovacion Docente</div>
        <h1>Panel de proyectos<br/>en tiempo real</h1>
        <p class="lead">
          Esta vista resume la API del proyecto y muestra los proyectos disponibles directamente desde el backend.
          Es una portada ligera para poder revisar el contenido en el navegador sin depender del frontend original.
        </p>
      </div>
      <aside class="panel hero-side">
        <div class="stat">
          <span class="stat-label">Estado</span>
          <div class="stat-value">Backend activo</div>
        </div>
        <div class="stat">
          <span class="stat-label">API</span>
          <div class="stat-value">/api/projects</div>
        </div>
        <div class="stat">
          <span class="stat-label">Salud</span>
          <div class="stat-value">/health</div>
        </div>
      </aside>
    </section>

    <section class="section">
      <div class="section-head">
        <div>
          <h2>Proyectos</h2>
          <p>Se cargan desde la API del backend.</p>
        </div>
        <p id="summary">Cargando...</p>
      </div>
      <div id="status" class="status skeleton">Consultando los datos del servidor...</div>
      <div id="grid" class="grid" style="margin-top:16px;"></div>
    </section>
  </main>

  <script>
    const statusEl = document.getElementById('status');
    const gridEl = document.getElementById('grid');
    const summaryEl = document.getElementById('summary');

    function renderProject(project) {
      const tags = [];
      if (project.faculty) tags.push(project.faculty);
      if (project.academicYear) tags.push(project.academicYear);
      if (project.line) tags.push(project.line);
      if (project.center) tags.push(project.center);

      return `
        <article class="card">
          <h3>${project.title ?? 'Proyecto sin titulo'}</h3>
          <p>${project.summary ?? 'Sin descripcion disponible.'}</p>
          <p style="margin-top:-6px;font-size:0.92rem;color:#cbd5e1;">
            <strong>Responsable:</strong> ${project.responsible || 'Sin asignar'}
          </p>
          <div class="tags">
            ${tags.slice(0, 4).map(tag => `<span class="tag">${tag}</span>`).join('')}
          </div>
        </article>
      `;
    }

    fetch('/api/projects')
      .then(async response => {
        if (!response.ok) throw new Error('No se pudieron cargar los proyectos');
        return response.json();
      })
      .then(projects => {
        const list = Array.isArray(projects) ? projects : [];
        summaryEl.textContent = `${list.length} proyecto(s) disponibles`;
        statusEl.className = 'status';
        statusEl.textContent = 'Datos cargados correctamente desde la API.';
        gridEl.innerHTML = list.length
          ? list.map(renderProject).join('')
          : '<div class="card"><h3>No hay proyectos</h3><p>La API respondió correctamente, pero no devolvió resultados.</p></div>';
      })
      .catch(error => {
        summaryEl.textContent = 'No se pudieron cargar los datos';
        statusEl.className = 'status error';
        statusEl.textContent = error.message;
        gridEl.innerHTML = '';
      });
  </script>
</body>
</html>
""";

    return Results.Text(html, "text/html; charset=utf-8");
});

app.MapGet("/api/projects", async (
    [AsParameters] ProjectQuery query,
    IProjectService service,
    CancellationToken cancellationToken) =>
{
    var projects = await service.GetProjectsAsync(query, cancellationToken);
    return Results.Ok(projects);
});

app.MapGet("/api/projects/{id:int}", async (
    int id,
    IProjectService service,
    CancellationToken cancellationToken) =>
{
    var project = await service.GetByIdAsync(id, cancellationToken);
    return project is null ? Results.NotFound() : Results.Ok(project);
});

app.MapGet("/api/projects/{id:int}/download", async (
    int id,
    IProjectService service,
    CancellationToken cancellationToken) =>
{
    var project = await service.GetByIdAsync(id, cancellationToken);
    if (project is null)
    {
        return Results.NotFound();
    }

    var filePath = ResolveProjectDocumentPath(project.DocumentFile);
    if (!File.Exists(filePath))
    {
        return Results.NotFound(new { message = "No se encontró el documento del proyecto." });
    }

    var contentType = GetContentType(filePath);
    return Results.File(
        filePath,
        contentType,
        fileDownloadName: Path.GetFileName(filePath),
        enableRangeProcessing: true);
});

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.Run();

static string ResolveProjectDocumentPath(string documentFile)
{
    var current = new DirectoryInfo(AppContext.BaseDirectory);

    while (current is not null)
    {
        var candidate = Path.Combine(current.FullName, "proyectos", documentFile);
        if (File.Exists(candidate))
        {
            return candidate;
        }

        current = current.Parent;
    }

    return Path.Combine(AppContext.BaseDirectory, "proyectos", documentFile);
}

static string GetContentType(string filePath)
{
    return Path.GetExtension(filePath).ToLowerInvariant() switch
    {
        ".pdf" => "application/pdf",
        ".doc" => "application/msword",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        _ => "application/octet-stream",
    };
}
