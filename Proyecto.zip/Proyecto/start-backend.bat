@echo off
cd /d "%~dp0backend\src\ProyectosInnova.Api"
dotnet run
