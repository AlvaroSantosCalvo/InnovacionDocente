# Proyectos de Innovacion Docente

Aplicacion web para consultar proyectos de innovacion docente, ver su informacion y descargar los PDFs asociados.

## Estructura

- `index.html`: interfaz principal.
- `data/`: datos de proyectos en formato JS y JSON.
- `img/`: imagenes usadas por la interfaz.
- `proyectos/`: PDFs descargables.
- `backend/`: solucion .NET del backend.
- `start-local-server.ps1`: servidor local para abrir la web desde `http://127.0.0.1:8000`.
- `start-backend.bat`: arranque rapido del backend en desarrollo.

## Ejecutar la web

Para que la descarga funcione correctamente, abre el proyecto con un servidor local:

```powershell
.\start-local-server.ps1
```

Despues entra en:

```text
http://127.0.0.1:8000/index.html
```

## Ejecutar el backend

Si necesitas levantar la API en desarrollo:

```bat
.\start-backend.bat
```

La API usa por defecto:

```text
http://localhost:5072
```

## Notas

- Los PDFs estan en la carpeta `proyectos/`.
- La web no necesita dependencias de npm.
- Si subes el repositorio a GitHub, no incluyas `bin/`, `obj/` ni logs.
