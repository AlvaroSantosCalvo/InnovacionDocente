const cards = document.getElementById('cards');
const navButtons = document.querySelectorAll('[data-scroll]');
const homeButton = document.getElementById('homeButton');
const userButton = document.getElementById('userButton');
const loadMoreButton = document.getElementById('loadMoreButton');
const dialogBackdrop = document.getElementById('dialogBackdrop');
const dialogTitle = document.getElementById('dialogTitle');
const dialogBody = document.getElementById('dialogBody');
const dialogClose = document.getElementById('dialogClose');
const yearFilter = document.getElementById('yearFilter');
const lineFilter = document.getElementById('lineFilter');
const callFilter = document.getElementById('callFilter');
const centerFilter = document.getElementById('centerFilter');
const searchInput = document.getElementById('searchInput');
const pageSizeInput = document.getElementById('pageSizeInput');

let projects = Array.isArray(window.PROJECTS_DATA)
  ? window.PROJECTS_DATA.map((project) => ({
      id: project.id,
      title: project.title,
      faculty: project.faculty,
      responsible: project.responsible || '',
      summary: project.summary,
      year: project.academicYear,
      call: project.call,
      line: project.line,
      center: project.center,
      documentFile: project.documentFile || '',
    }))
  : [];

const filterState = {
  year: 'Todos',
  line: 'Todas',
  call: 'Cualquiera',
  center: 'Cualquiera',
  search: '',
  pageSize: 3,
  loaded: 3,
};

function downloadTextFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

async function downloadProject(project) {
  const fileName = project.documentFile || `${project.title}.pdf`;
  const localUrl = `./proyectos/${encodeURI(fileName)}`;

  try {
    const response = await fetch(localUrl);
    if (!response.ok) {
      throw new Error('No se pudo descargar el documento.');
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(objectUrl);
  } catch {
    const link = document.createElement('a');
    link.href = localUrl;
    link.download = fileName;
    link.rel = 'noopener';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
}

function getFilteredProjects() {
  readFilters();
  return projects.filter(matchesFilters);
}

function downloadFilteredProjects() {
  const filtered = getFilteredProjects();
  const payload = {
    exportedAt: new Date().toISOString(),
    filters: {
      year: filterState.year,
      line: filterState.line,
      call: filterState.call,
      center: filterState.center,
      search: filterState.search,
      pageSize: filterState.pageSize,
    },
    projects: filtered.map((project) => ({
      id: project.id,
      title: project.title,
      faculty: project.faculty,
      responsible: project.responsible,
      summary: project.summary,
      year: project.year,
      call: project.call,
      line: project.line,
      center: project.center,
      documentFile: project.documentFile,
    })),
  };
  downloadTextFile('proyectos-filtrados.json', JSON.stringify(payload, null, 2), 'application/json');
}

async function loadProjects() {
  return Promise.resolve();
}

function openDialog(project) {
  dialogTitle.textContent = project.title;
  dialogBody.innerHTML = '';

  const rows = [
    ['Facultad', project.faculty],
  ];

  if (project.responsible) {
    rows.push(['Responsable', project.responsible]);
  }

  rows.push(
    ['Convocatoria', project.call],
    ['A\u00f1o', project.year],
    ['L\u00ednea', project.line],
    ['Centro', project.center],
  );

  rows.forEach(([label, value]) => {
    const row = document.createElement('div');
    const strong = document.createElement('strong');
    strong.textContent = `${label}:`;
    row.appendChild(strong);
    row.appendChild(document.createTextNode(` ${value}`));
    dialogBody.appendChild(row);
  });

  const summary = document.createElement('div');
  summary.textContent = project.summary;
  dialogBody.appendChild(summary);
  dialogBackdrop.classList.add('open');
}

function closeDialog() {
  dialogBackdrop.classList.remove('open');
}

function scrollToTarget(selector) {
  const target = document.querySelector(selector);
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function populateSelect(select, values, placeholder) {
  const current = select.value || placeholder;
  const uniqueValues = [...new Set(values.filter((value) => value !== undefined && value !== null && value !== ''))];
  select.innerHTML = `<option>${placeholder}</option>` + uniqueValues.map((value) => `<option>${value}</option>`).join('');
  if ([placeholder, ...uniqueValues].includes(current)) {
    select.value = current;
  }
}

function setupFilters() {
  if (!projects.length) {
    return;
  }
  populateSelect(yearFilter, projects.map((p) => p.year), 'Todos');
  populateSelect(lineFilter, projects.map((p) => p.line), 'Todas');
  populateSelect(callFilter, projects.map((p) => p.call), 'Cualquiera');
  populateSelect(centerFilter, projects.map((p) => p.center), 'Cualquiera');
}

function readFilters() {
  filterState.year = yearFilter.value;
  filterState.line = lineFilter.value;
  filterState.call = callFilter.value;
  filterState.center = centerFilter.value;
  filterState.search = searchInput.value.trim().toLowerCase();
  filterState.pageSize = Math.max(1, Number(pageSizeInput.value) || 3);
}

function matchesFilters(project) {
  const yearMatch = filterState.year === 'Todos' || project.year === filterState.year;
  const lineMatch = filterState.line === 'Todas' || project.line === filterState.line;
  const callMatch = filterState.call === 'Cualquiera' || project.call === filterState.call;
  const centerMatch = filterState.center === 'Cualquiera' || project.center === filterState.center;
  const searchText = `${project.title} ${project.faculty} ${project.summary} ${project.line} ${project.center}`.toLowerCase();
  const searchMatch = !filterState.search || searchText.includes(filterState.search);
  return yearMatch && lineMatch && callMatch && centerMatch && searchMatch;
}

function renderProjects() {
  readFilters();
  const filtered = projects.filter(matchesFilters);
  const limit = Math.max(filterState.pageSize, filterState.loaded);
  const visible = filtered.slice(0, limit);
  const multipleCalls = new Set(projects.map((project) => project.call)).size > 1;
  if (!projects.length) {
    cards.innerHTML = '<article class="card"><h2 class="project-title">Cargando proyectos...</h2><p class="project-desc">Estamos consultando la API del backend.</p></article>';
    loadMoreButton.disabled = true;
    loadMoreButton.textContent = 'Cargando...';
    return;
  }
  cards.innerHTML = visible.map((project, index) => `
        <article class="card" data-index="${index}" data-id="${project.id}">
          <h2 class="project-title">${project.title}</h2>
          <div class="project-faculty">${project.faculty}</div>
          <p class="project-desc">${project.summary}</p>
          <div class="card-footer">
            <div class="meta">
              <span>A&ntilde;o: ${project.year}</span>
              ${multipleCalls ? `<span>Convocatoria: ${project.call}</span>` : ``}
            </div>
            <div class="card-actions">
              <button class="project-btn" type="button" data-action="view" data-id="${project.id}">Ver proyecto</button>
              <button class="download-btn" type="button" data-action="download" data-id="${project.id}">Descargar</button>
            </div>
          </div>
        </article>
      `).join('');

  const canLoadMore = filtered.length > visible.length;
  loadMoreButton.disabled = !canLoadMore;
  loadMoreButton.textContent = canLoadMore ? 'Cargar Mas' : 'Sin mas resultados';
}

navButtons.forEach((button) => {
  button.addEventListener('click', () => scrollToTarget(button.dataset.scroll));
});

homeButton.addEventListener('click', () => {
  scrollToTarget('#top');
});

userButton.addEventListener('click', () => {
  openDialog({
    title: 'Perfil de usuario',
    faculty: 'Acceso rapido',
    call: 'Cuenta',
    year: 'Inicio de sesi\u00f3n',
    line: '\u00c1rea privada',
    center: 'Panel personal',
    summary: 'Este espacio puede conectarse despu\u00e9s con un perfil o un \u00e1rea privada.',
  });
});

cards.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const id = Number(button.dataset.id);
  const project = projects.find((item) => item.id === id);
  if (!project) return;
  if (button.dataset.action === 'download') {
    downloadProject(project);
    return;
  }
  openDialog(project);
});

[yearFilter, lineFilter, callFilter, centerFilter, searchInput, pageSizeInput].forEach((control) => {
  control.addEventListener('change', () => {
    filterState.loaded = Math.max(1, Number(pageSizeInput.value) || 3);
    renderProjects();
  });
  control.addEventListener('input', () => {
    filterState.loaded = Math.max(1, Number(pageSizeInput.value) || 3);
    renderProjects();
  });
});

loadMoreButton.addEventListener('click', () => {
  filterState.loaded += filterState.pageSize;
  renderProjects();
});

dialogClose.addEventListener('click', closeDialog);
dialogBackdrop.addEventListener('click', (event) => {
  if (event.target === dialogBackdrop) closeDialog();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeDialog();
});

loadProjects()
  .then(() => {
    setupFilters();
    renderProjects();
  })
  .catch((error) => {
    cards.innerHTML = `<article class="card"><h2 class="project-title">No se pudieron cargar los proyectos</h2><p class="project-desc">${error.message}</p></article>`;
    loadMoreButton.disabled = true;
    loadMoreButton.textContent = 'Sin resultados';
  });
